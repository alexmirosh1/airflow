from datetime import datetime
import os
import json
import glob
import dill
import pandas as pd

path = os.environ.get('PROJECT_PATH', '..')


def predict():
    source = glob.glob(f'{path}/data/models/*')
    latest_file = max(source, key=os.path.getctime)
    with open(latest_file, 'rb') as file:
        model = dill.load(file)

    prediction = []
    for filename in glob.glob(f'{path}/data/test/*.json'):
        with open(filename, 'r', encoding='utf-8') as name:
            form = json.load(name)
            df = pd.DataFrame.from_dict([form])
            y = model.predict(df)
            x = {'car_id': df.id[0], 'pred': y}
            prediction.append(x)
    df_prediction = pd.DataFrame.from_dict(prediction)
    df_prediction.to_csv(f'{path}/data/predictions/prediction_{datetime.now().strftime("%Y%m%d%H%M")}.csv')


if __name__ == '__main__':
    predict()
